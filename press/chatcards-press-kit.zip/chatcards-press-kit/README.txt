ChatCards basın kiti / press kit

TR
- Görseller uygulamanın SENTETİK örnek grubundan alınmıştır. Adlar (Mert, Deniz,
  Selin, Can, Jake, Ava, Zoe, Alex, Sam...) ve sayılar uydurmadır; gerçek bir
  sohbet kullanılmamıştır.
- cards/: paylaşılabilir kartların ekran görüntüleri (1080 genişlik).
- screens/: ana ekran ve gizlilik ekranı.
- icon/: uygulama ikonu (PNG 1024 ve SVG).
- social/: 1200x630 bağlantı önizleme görselleri (TR, EN, PT, HI).
- Lütfen WhatsApp logosunu ChatCards görselleriyle birlikte kullanmayın.
  ChatCards bağımsız bir uygulamadır; WhatsApp ya da Meta ile bağlantısı yoktur.
- Bağlantı: https://emrekaramustafa.github.io/chatcards-site/go/?c=press_<site>

EN
- All visuals come from the app's SYNTHETIC sample group. Names (Mert, Deniz,
  Selin, Can, Jake, Ava, Zoe, Alex, Sam...) and numbers are made up; no real
  chat was used.
- cards/: shareable card screenshots (1080 wide).
- screens/: home and privacy screens.
- icon/: app icon (PNG 1024 and SVG).
- social/: 1200x630 link preview images (TR, EN, PT, HI).
- Please don't place the WhatsApp logo next to ChatCards visuals. ChatCards is
  independent and not affiliated with WhatsApp or Meta.
- Link: https://emrekaramustafa.github.io/chatcards-site/go/?c=press_<site>
